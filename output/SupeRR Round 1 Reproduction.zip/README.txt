Run from the extracted folder.
Dependencies: pandas, numpy, reportlab.
Generate submission rankings: python rank_pressure.py
Generate submission PDF: python render_report.py
Audit chronological cutoff: python audit_pressure_cutoff.py
Rerun forecasting experiments: python validate_ordinary_prior.py
Test role-specific bowling pressure: python validate_role_pressure.py
Rebuild scouting evidence: python build_scouting_evidence.py
Render the scouting dossier: python render_scouting_dossier.py
