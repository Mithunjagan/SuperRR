"""Render the dossier from the verified scouting evidence."""
import csv
import json
from html import escape
from pathlib import Path

from reportlab.graphics.shapes import Drawing, Line, Rect, Circle, String
from reportlab.lib.colors import HexColor, white
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Table, TableStyle

out = Path("output")
def read(name):
    return json.loads((out / name).read_text(encoding="utf-8"))

with (out / "scouting_player_evidence.csv").open(encoding="utf-8", newline="") as handle:
    evidence = list(csv.DictReader(handle))
top = {role: [row for row in evidence if row["role"] == role and int(row["rank"]) <= 10]
       for role in ("Batters", "Bowlers")}
rr = read("rr_2026_deployment.json")
ranks = read("revised_rankings.json")
prior = read("ordinary_prior_validation.json")
experiment_d = read("role_pressure_validation.json")
ink, muted, pink, blue, teal, pale, grid = map(HexColor, [
    "#17253A", "#43546D", "#A31857", "#235D88", "#16776B", "#EFF3F7", "#CCD7E3"])
styles = {}
for name, size, leading, color, bold, space in [
    ("tag",9,13,pink,True,8), ("title",28,32,ink,True,8), ("intro",11,15.5,muted,False,12),
    ("head",13,17,ink,True,5), ("body",10.2,14.3,ink,False,9), ("note",8.8,12.2,muted,False,7),
    ("cell",8.6,11,ink,False,0), ("th",8.1,10,white,True,0),
]:
    styles[name] = ParagraphStyle(name, fontName="Helvetica-Bold" if bold else "Helvetica",
        fontSize=size, leading=leading, textColor=color, spaceAfter=space,
        spaceBefore=8 if name in ("head","note") else 0)
story = []

def text(value, style="body"):
    story.append(Paragraph(value, styles[style]))

def page(title, intro):
    if story:
        story.append(PageBreak())
    text("SUPERR SELECTOR  /  RAJASTHAN ROYALS  /  15 NOVEMBER 2026", "tag")
    text(title, "title")
    text(intro, "intro")

def section(title, body):
    text(title,"head")
    text(body)

def table(headers, data, widths, padding=5):
    rows = [[Paragraph(value, styles["th"]) for value in headers]]
    rows.extend([Paragraph(escape(str(value)), styles["cell"]) for value in row] for row in data)
    tab = Table(rows, colWidths=widths, repeatRows=1, hAlign="LEFT")
    tab.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),ink), ("ROWBACKGROUNDS",(0,1),(-1,-1),[white,pale]),
        ("VALIGN",(0,0),(-1,-1),"MIDDLE"), ("TOPPADDING",(0,0),(-1,-1),padding),
        ("BOTTOMPADDING",(0,0),(-1,-1),padding),
    ]))
    story.append(tab)

def link(label, url):
    return f'<link href="{url}" color="#235D88">{label}</link>'

def pct(value):
    return f"{float(value):.0%}"

def scatter():
    d=Drawing(480,180)
    def x(v): return 46 + (v-14)*18.4
    def y(v): return 28 + (v-.45)*255
    for v in (.5,.6,.7,.8,.9):
        d.add(Line(46,y(v),451,y(v),strokeColor=grid,strokeWidth=.5))
        d.add(String(39,y(v)-3,pct(v),textAnchor="end",fontSize=8,fillColor=muted))
    for v in (15,20,25,30,35):
        d.add(String(x(v),15,str(v),textAnchor="middle",fontSize=8,fillColor=muted))
    d.add(String(46,167,"Matches with positive adjusted value",fontSize=8.5,fillColor=muted))
    d.add(String(250,1,"Model A rating",textAnchor="middle",fontSize=8.5,fillColor=muted))
    labels={"Dewald Brevis":("Brevis",-7,-12,"end"),"Heinrich Klaasen":("Klaasen",8,6,"start"),
            "Rashid Khan":("Rashid",-7,9,"end"),"Jofra Archer":("Archer",8,-10,"start")}
    for role,rows in top.items():
        for row in rows:
            px,py=x(float(row["rating"])),y(float(row["positive_match_share"]))
            if role=="Batters":
                d.add(Circle(px,py,3.7,fillColor=pink,strokeColor=None))
            else:
                d.add(Rect(px-3.2,py-3.2,6.4,6.4,fillColor=blue,strokeColor=None))
            if row["player"] in labels:
                label,dx,dy,anchor=labels[row["player"]]
                d.add(String(px+dx,py+dy,label,textAnchor=anchor,fontSize=8,fontName="Helvetica-Bold",fillColor=ink))
    d.add(Circle(328,170,3.3,fillColor=pink,strokeColor=None))
    d.add(String(335,167,"Batters",fontSize=8,fillColor=muted))
    d.add(Rect(387,167,6,6,fillColor=blue,strokeColor=None))
    d.add(String(398,167,"Bowlers",fontSize=8,fillColor=muted))
    return d

def phase_chart():
    d=Drawing(480,221)
    phases=(("Powerplay",blue),("Middle",teal),("Death",pink))
    for i,(phase,color) in enumerate(phases):
        x=126+i*88
        d.add(Rect(x,206,9,8,fillColor=color,strokeColor=None))
        d.add(String(x+13,206,phase,fontSize=8,fillColor=muted))
    for balls in (0,100,200,300):
        x=126+.86*balls
        d.add(Line(x,23,x,198,strokeColor=grid,strokeWidth=.45))
        d.add(String(x,12,str(balls),textAnchor="middle",fontSize=8,fillColor=muted))
    for i,row in enumerate(rr["bowling"][:8]):
        y=187-i*21
        d.add(String(118,y,row["bowler_name"],textAnchor="end",fontSize=8.7,fillColor=ink))
        x=126
        for phase,color in phases:
            balls=row[phase]
            width=.86*balls
            if balls:
                d.add(Rect(x,y-2,width,9,fillColor=color,strokeColor=None))
                if width>=19:
                    d.add(String(x+width/2,y,str(balls),textAnchor="middle",fontSize=7,fillColor=white))
            x+=width
        d.add(String(x+5,y,str(row["Total"]),fontSize=8,fillColor=muted))
    d.add(String(250,0,"Legal deliveries for Rajasthan Royals",textAnchor="middle",fontSize=8.5,fillColor=muted))
    return d


page("Rajasthan Royals scouting dossier",
     "Three decisions from the pressure analysis. Auction recommendations use the 2026 squad and depend on confirmed 2027 availability.")
table(["Decision","Recommendation","Evidence and condition"],[
    ["Plan around Archer","Protect new-ball and death coverage.",
     "Archer delivered 198 powerplay and 102 death balls for RR. If he leaves, prioritize a seamer who can cover both phases."],
    ["Scout Klaasen","First external option for middle-order acceleration.",
     "Positive in 18 of 23 pressure matches. One match supplied 16% of his positive value. Pursue if he is available and improves RR's No. 4–6 mix enough to justify the overseas slot."],
    ["Benchmark Rashid","Set the benchmark for middle-overs spin.",
     "Positive in 31 of 44 pressure matches and second after removing his best. RR already deploys Jadeja, Bishnoi and Yash Punja. Pursue if the role opens and he is available."],
],[104,138,246])
text("Pressure rating and match-to-match consistency","head")
story.append(scatter())
text("Each mark is one of the 20 top-ten players. A positive match has an adjusted contribution above zero. A high share from a small sample carries more uncertainty.","note")
section("The highest rating can come from a concentrated sample",
        "Brevis ranks first among batters. His best match supplied 36% of his positive value and removing it drops him to 12th. "
        "Klaasen moves from third to fourth after the same check, which is why he leads the conditional batting shortlist.")

page("How the pressure rating works","Model A determines both ordered top tens.")
section("Sample and pressure situations",
        "The data contains 184,476 regulation delivery events from 771 screened matches (352 IPL, 419 T20I) from 2022 to 2026. Of 883 "
        "match records, 30 were emerging tournaments, 16 lacked deliveries, 38 had revision indicators, 15 lacked both innings or a "
        "complete result, and 13 failed reconciliation. Exclusions are sequential. Super Overs are excluded.")
text("A chase qualifies before the ball with 1 to 30 legal balls remaining, 8 to 16 required runs per over and at least two wickets in hand. "
     "A first-innings delivery qualifies when at least three wickets have fallen before 60 legal balls. Together those rules identify "
     "14,381 delivery events before role and player filters.")
section("Actual and expected contribution",
        "Batters earn runs off the bat minus dismissal cost. Bowlers earn credited wicket value minus charged runs, including wides and "
        "no-balls, with exposure counted in legal balls. Powerplay, middle and death wickets are worth 8, 6 and 4 run equivalents. "
        "Run-outs earn no bowling wicket credit. Batting exposure omits wides and off-delivery penalties.")
text("The batting and bowling expectations use earlier dates only. Within each format, innings and phase, the model adjusts for balls "
     "remaining, wickets lost and required run rate or first-innings current run rate. The opposing striker or bowler's earlier ordinary "
     "residual in the same format, innings and phase supplies the opponent adjustment.")
section("Ranking and eligibility",
        "<b>Rating = 100 × sum of actual minus expected value ÷ (eligible pressure balls + 60).</b> An event counts after the player has "
        "120 ordinary balls of history. Ranking requires 60 pressure balls across eight matches. Lift compares pressure residuals with the "
        "player's ordinary adjusted rate and remains outside the headline rating.")
text("Reproduction details","head")
text("Balls-left groups are six balls within the last 30 and 12 balls earlier. Wicket cut points are 1, 2, 3, 4, 6 and 9 lost. Rate bands "
     "are two runs per over, capped at 30. The starting phase reference uses 100 virtual balls at +1 for batting and -1 for bowling. "
     "The two state levels borrow 100 and 60 balls from their parent estimates. Opponent and ordinary-player rates use 60 virtual "
     "balls toward zero. The one-run primary extra marked “other” is treated as a no-ball. Retire-outs are excluded from batting dismissal cost.","note")

for role in ("Batters","Bowlers"):
    page(f"Top 10 {role.lower()}",f"{ranks[role]['eligible']} players met the Model A eligibility criteria.")
    rows=[]
    for r in top[role]:
        rows.append([r["rank"],r["player"],f"{float(r['rating']):.2f}",r["pressure_balls"],r["pressure_matches"],
                     pct(r["positive_match_share"]),pct(r["best_match_share"]),f"{float(r['worst_match_value']):+.1f}",
                     pct(r["bootstrap_top10_share"])])
    table(["Rank","Player","Rating","Balls","Games","Positive<br/>games","Best<br/>share","Worst<br/>match","Top 10<br/>share"],
          rows,[36,112,47,37,42,55,51,53,55],4)
    text("Best share is the biggest match's share of all positive adjusted value. Worst match is the lowest observed total in run equivalents "
         "and reflects opportunity as well as performance. Top-ten frequencies use 1,000 whole-match resamples with baselines and eligibility fixed.","note")
    text("Format exposure and best-match sensitivity","head")
    rows=[]
    for r in top[role]:
        fmt=[]
        for name in ("IPL","T20I"):
            rate=r[name+"_residual_per100"]
            fmt.append(f"{r[name+'_pressure_balls']} / {float(rate):+.1f}" if rate else "0 / —")
        after=f"No. {int(float(r['drop_best_rank']))}" if r["drop_best_rank"] else "Ineligible"
        rows.append([r["player"],*fmt,after])
    table(["Player","IPL balls / value per 100","T20I balls / value per 100","Rank without best match"],
          rows,[135,113,115,125],4)
    text("Format rates are unshrunk run equivalents per 100 pressure balls. Interpret small splits cautiously. The removal test holds other players' scores fixed.","note")

page("Where a signing would help",
     f"Actual deployment in {rr['matches']} screened Royals IPL 2026 matches. The chart covers the eight most-used bowlers.")
story.append(phase_chart())
section("The top four already have incumbents",
        "Jaiswal and Sooryavanshi opened in all 15 screened matches, Jurel batted at No. 3 in all 15, and Parag batted at No. 4 in "
        "10 of his 13 batting appearances. Iyer makes sense if RR needs to replace or move a No. 3–4.")
section("A middle-order signing needs to beat an incumbent",
        "Ferreira batted at No. 5 or 6 in 10 of 13 appearances. Hetmyer covered Nos. 4–6. Klaasen is a conditional upgrade candidate "
        "if his role opens. Brevis is an alternative with a more concentrated pressure sample.")
section("Plan bowling around Archer's status",
        "Archer and Burger led powerplay usage. Archer and Brijesh Sharma delivered 195 death balls between them. If Archer stays, "
        "compare a second dual-phase seamer with a middle-order signing. If he leaves, prioritize the open pace role. Jadeja, "
        "Yash Punja and Bishnoi already account for 462 middle-over deliveries.")
text("The chart measures usage across screened matches. A lower count alone does not establish a phase weakness. "
     +link("Official IPL 2026 Rajasthan Royals squad","https://www.iplt20.com/teams/rajasthan-royals")+".","note")

page("Auction decision matrix",
     "Assessment as of 15 November 2026. Check release or trade status, registration, available slots and price before bidding.")
table(["Player / 2026 club","Role and slot","Acquisition condition and fallback"],[
    ["Jofra Archer / RR","Powerplay and death seam. Overseas.",
     "Retention and workload planning. If he leaves, assess Hazlewood and compare with Burger and domestic pace depth."],
    ["Heinrich Klaasen / SRH","No. 4–6 acceleration. Overseas.",
     "Prioritize if the role opens and he is available. Compare with Ferreira and Hetmyer. Brevis is a higher-uncertainty alternate."],
    ["Josh Hazlewood / RCB","Dual-phase seam. Overseas.",
     "Assess if Archer leaves or a specific pace gap remains. Check workload and availability. Use existing RR pace depth if it covers the role."],
    ["Rashid Khan / GT","Middle-overs leg-spin. Overseas.",
     "Benchmark while availability is pending. Act if the spin role opens. Compare with Jadeja, Bishnoi, Yash Punja and domestic option Varun."],
    ["Shreyas Iyer / PBKS","No. 3–4 recovery. Domestic.",
     "Pursue if available and RR needs to reshuffle Nos. 3–4. Jurel and Parag are the incumbents."],
    ["Varun Chakravarthy / KKR","Middle-overs spin. Domestic.",
     "Conditional alternate if available. Second in the IPL-only bowling analysis. Compare against retaining Bishnoi."],
    ["Dewald Brevis / CSK","No. 4–5 acceleration. Overseas.",
     "Conditional upside option. Best-match dependence and overlap with incumbents argue for a cautious valuation."],
    ["Naveen ul Haq","Pace depth. Overseas.",
     "Watchlist pending registration and availability. Exactly 60 qualifying balls. Start with the better-supported seam options."],
    ["Iftikhar Ahmed / Shaheen Afridi","Performance benchmarks.",
     "Keep their statistical ranks. No actionable 2027 auction availability is verified."],
],[113,130,245],5)
text("The matrix uses last verified season associations. Cricbuzz reports a 17 November retention deadline. Refresh the shortlist "
     "against official releases and the eventual auction register. Overseas roles consume an overseas squad and playing slot if selected.","note")
text(link("Official 2026 IPL retention list","https://www.iplt20.com/news/article/tata-ipl-2026-player-retentions-announced")
     +" · "+link("Official 2026 auction results","https://www.iplt20.com/auction/2026/teams")
     +" · "+link("2027 retention timeline","https://www.cricbuzz.com/cricket-news/140762/bcci-extends-ipl-retention-deadline-to-november-17-cricbuzzcom"),"note")

page("What validation supports","Model A stayed in use after chronological and match-level checks.")
text("Experiments A, B and C","head")
rows=[]
for key,label in (("current","A · Current rating"),("ordinary_prior","B · Ordinary-ability prior"),
                  ("ordinary_prior_match_cap","B + match exposure cap"),("robust_match_value","C · Cap extreme match values")):
    b,w=(prior[role]["metrics"][key] for role in ("Batters","Bowlers"))
    rows.append([label,f"{b['dev_rmse']:.2f} / {w['dev_rmse']:.2f}",
                 f"{b['holdout_rmse']:.2f} / {b['holdout_spearman']:.3f}",
                 f"{w['holdout_rmse']:.2f} / {w['holdout_spearman']:.3f}"])
table(["Experiment","2024–25 RMSE<br/>Bat / Bowl","2026 batters<br/>RMSE / rank corr.","2026 bowlers<br/>RMSE / rank corr."],
      rows,[160,98,115,115])
text("B improved both batting metrics in 2026. C lowered bowling error and matched the baseline rank correlation. The paired match-bootstrap "
     "intervals for their error improvements included zero. The exposure cap reduced rank correlation in both roles.","note")
text("Experiment D · Role-specific first-innings pressure","head")
rows=[]
for year,fold in experiment_d["folds"].items():
    rows.append([f"{year} · {fold['players']} bowlers",*
                 [f"{fold['variants'][v]['rmse']:.2f} / {fold['variants'][v]['spearman']:.3f}" for v in ("A","D1","D2")]])
table(["Year and cohort","A · Collapse rule","D1 · 9 RPO","D2 · Format/phase quartile"],rows,[142,106,107,133])
text("Entries show RMSE and Spearman rank correlation. D2 improved the previously inspected 2026 diagnostic, but both D variants "
     "were worse in both historical folds. All variants predicted the same original Model A outcome for the same players within each fold.","note")
section("What remains uncertain",
        "The 2026 diagnostic covers 14 batters and 16 bowlers and has been inspected in several experiments. Rank stability is conditional "
        "on the observed matches, fitted baselines and eligibility. Fixed wicket values and the distribution of pressure opportunities remain limitations.")
text("The cutoff audit found that changing future runs and wickets left earlier scores and frozen expectations identical. Sources include "
     "the supplied brief and CSVs, Model A evidence and chronological experiment outputs. "
     +link("Competition listing","https://unstop.com/hackathons/crp-superr-selector-season-2-help-shape-rajasthan-royals-ipl-2027-auction-strategy-rajasthan-royals-1792758")+".","note")

def footer(canvas, doc):
    canvas.setStrokeColor(grid)
    canvas.line(48,42,A4[0]-48,42)
    canvas.setFont("Helvetica",8)
    canvas.setFillColor(muted)
    canvas.drawString(48,29,"SupeRR Selector  /  Scouting dossier")
    canvas.drawRightString(A4[0]-48,29,str(doc.page))

path=out/"pdf/SupeRR Round 1 Scouting Dossier.pdf"
path.parent.mkdir(parents=True,exist_ok=True)
doc=SimpleDocTemplate(str(path),pagesize=A4,leftMargin=48,rightMargin=48,topMargin=42,bottomMargin=53,
                      title="SupeRR Selector Round 1 | Rajasthan Royals scouting dossier")
doc.build(story,onFirstPage=footer,onLaterPages=footer)


